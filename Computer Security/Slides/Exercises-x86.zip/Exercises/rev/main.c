
#include <stdio.h>
#include <string.h>

char key_1[] = "\xf1\xd6\xc3\xad\x19\xc8\x6f\x22\xc6\x74\x9f\x94\x2e\x73\xbe\x8a\x2a\x12\x17\x62\x08\x6a\x7a\xbc\x5c\xec\x5b\x6a\x0e";
char key_2[] = "\x97\xba\xa2\xca\x62\xbf\x5f\x55\x99\x0d\xaf\xe1\x71\x18\xd0\xba\x5d\x4d\x65\x51\x7e\x59\x08\xcf\x6d\x82\x3c\x4b\x73";

int main() {
    char buf[30];
    char dst[30];
    
    for(int i = 0; i < 30; i++) 
        dst[i] = key_1[i] ^ key_2[i];
    
    scanf("%29s", buf);
    if (!strcmp(buf, dst))
        puts("Correct flag :)");
    else
        puts("Incorrect flag :(");
    return 0;
}