void foo();
void bar();

int main(int argc, char const *argv[])
{
    foo();
    return 0;
}

void foo()
{
    int a;
    int b;
    int c;

    a = 0x10;
    b = 0x20;
    c = a + b;
    bar();
    c = c * 0x10;
}

void bar()
{
    int x;
    int y;
    int z;

    x = 0x1;
    y = 0x2;
    z = x + y;
}
