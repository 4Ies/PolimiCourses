#include <stdio.h>

void foo();
int sum(int a, int b);

int main(int argc, char const *argv[])
{
    foo();
    return 0;
}

void foo()
{
    int a;
    int b;
    int c;

    scanf("%d", &a);
    scanf("%d", &b);
    c = sum(a, b);
    printf("Sum is %d\n", c);
}

int sum(int a, int b)
{
    return a + b;
}